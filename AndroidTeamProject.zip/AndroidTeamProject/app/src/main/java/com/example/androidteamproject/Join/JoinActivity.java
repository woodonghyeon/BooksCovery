package com.example.androidteamproject.Join;

import android.app.Activity;
import android.os.Bundle;

import com.example.androidteamproject.R;

public class JoinActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);





    }
}
